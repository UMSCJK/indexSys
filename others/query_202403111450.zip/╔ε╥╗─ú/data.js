const data = {
	"exam": "2024年深圳市高三年级第一次调研考试",
	"schoolName": "深圳市云顶学校",
	"classNum": 4,
	"main": {
		"黄恺浩": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [369, 32041] }, "chn": { "ori": [78, 32982] }, "mat": { "ori": [28, 36384] }, "eng": { "ori": [101, 19115] }, "phy": { "ori": [29, 33953] }, "che": { "ori": [32, 27760], "trs": [64, 27734], }, "sel": { "ori": [53, 4840], "trs": [69, 4840] } } },
		"曹俊楷": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [346, 34297] }, "chn": { "ori": [59, 38032] }, "mat": { "ori": [46, 28591] }, "eng": { "ori": [84, 25199] }, "phy": { "ori": [40, 27598] }, "che": { "ori": [14, 33119], "trs": [50, 33119], }, "sel": { "ori": [42, 9113], "trs": [67, 8904] } } },
		"庄敬轩": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [338, 34909] }, "chn": { "ori": [73, 35598] }, "mat": { "ori": [48, 27437] }, "eng": { "ori": [42, 33417] }, "phy": { "ori": [34, 31313] }, "che": { "ori": [33, 27285], "trs": [65, 26810], }, "sel": { "ori": [53, 5961], "trs": [76, 5961] } } },
		"彭青辰": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [335, 35114] }, "chn": { "ori": [74, 35175] }, "mat": { "ori": [35, 34121] }, "eng": { "ori": [46, 33031] }, "phy": { "ori": [36, 30142] }, "che": { "ori": [37, 25289], "trs": [67, 24684], }, "sel": { "ori": [55, 5262], "trs": [77, 5262] } } },
		"胡俊婷": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [319, 36125] }, "chn": { "ori": [83, 28952] }, "mat": { "ori": [44, 29700] }, "eng": { "ori": [55, 31887] }, "phy": { "ori": [20, 37174] }, "che": { "ori": [24, 30979], "trs": [60, 30643], }, "sel": { "ori": [28, 10644], "trs": [57, 10644] } } },
		"姚文祥": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [310, 36613] }, "chn": { "ori": [69, 36848] }, "mat": { "ori": [26, 36875] }, "eng": { "ori": [74, 28051] }, "phy": { "ori": [24, 36036] }, "che": { "ori": [28, 29516], "trs": [62, 29099], }, "sel": { "ori": [26, 25613], "trs": [55, 25613] } } },
		"刘梓铱": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [306, 36782] }, "chn": { "ori": [64, 37641] }, "mat": { "ori": [37, 33294] }, "eng": { "ori": [53, 32168] }, "phy": { "ori": [29, 33953] }, "che": { "ori": [25, 30653], "trs": [60, 30643], }, "sel": { "ori": [36, 9992], "trs": [63, 9992] } } },
		"谢紫欣": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [304, 36890] }, "chn": { "ori": [78, 32982] }, "mat": { "ori": [38, 32855] }, "eng": { "ori": [70, 28987] }, "phy": { "ori": [12, 38218] }, "che": { "ori": [18, 32587], "trs": [54, 32585], }, "sel": { "ori": [21, 25888], "trs": [52, 25888] } } },
		"林泽鹏": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [301, 37012] }, "chn": { "ori": [67, 37243] }, "mat": { "ori": [43, 30285] }, "eng": { "ori": [53, 32168] }, "phy": { "ori": [13, 38160] }, "che": { "ori": [25, 30653], "trs": [60, 30643], }, "sel": { "ori": [42, 22912], "trs": [65, 22637] } } },
		"刘姝涵": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [295, 37221] }, "chn": { "ori": [69, 36848] }, "mat": { "ori": [15, 38209] }, "eng": { "ori": [64, 30291] }, "phy": { "ori": [22, 36646] }, "che": { "ori": [30, 28689], "trs": [63, 28658], }, "sel": { "ori": [37, 24136], "trs": [62, 23897] } } },
		"柯思敏": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [294, 37252] }, "chn": { "ori": [74, 35175] }, "mat": { "ori": [38, 32855] }, "eng": { "ori": [45, 33128] }, "phy": { "ori": [12, 38218] }, "che": { "ori": [19, 32378], "trs": [55, 32371], }, "sel": { "ori": [47, 7889], "trs": [70, 7889] } } },
		"王炜彬": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [291, 37342] }, "chn": { "ori": [66, 37401] }, "mat": { "ori": [21, 37661] }, "eng": { "ori": [66, 29875] }, "phy": { "ori": [27, 34838] }, "che": { "ori": [15, 33013], "trs": [51, 33013], }, "sel": { "ori": [38, 6104], "trs": [60, 6104] } } },
		"黄沛瑶": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [274, 37804] }, "chn": { "ori": [81, 30734] }, "mat": { "ori": [19, 37897] }, "eng": { "ori": [42, 33417] }, "phy": { "ori": [17, 37740] }, "che": { "ori": [20, 32132], "trs": [56, 32126], }, "sel": { "ori": [36, 6153], "trs": [59, 6153] } } },
		"张君灵": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [266, 37940] }, "chn": { "ori": [62, 37825] }, "mat": { "ori": [31, 35510] }, "eng": { "ori": [33, 34095] }, "phy": { "ori": [19, 37392] }, "che": { "ori": [20, 32132], "trs": [56, 32126], }, "sel": { "ori": [46, 5691], "trs": [65, 5691] } } },
		"詹雅婷": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [265, 37954] }, "chn": { "ori": [58, 38085] }, "mat": { "ori": [20, 37793] }, "eng": { "ori": [64, 30291] }, "phy": { "ori": [10, 38301] }, "che": { "ori": [15, 33013], "trs": [51, 33013], }, "sel": { "ori": [34, 10205], "trs": [62, 10118] } } },
		"吕金岳": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [263, 37975] }, "chn": { "ori": [58, 38085] }, "mat": { "ori": [28, 36384] }, "eng": { "ori": [38, 33756] }, "phy": { "ori": [24, 36036] }, "che": { "ori": [16, 32884], "trs": [52, 32884], }, "sel": { "ori": [36, 9992], "trs": [63, 9992] } } },
		"朱本博": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [261, 38007] }, "chn": { "ori": [69, 36848] }, "mat": { "ori": [20, 37793] }, "eng": { "ori": [34, 34039] }, "phy": { "ori": [15, 37967] }, "che": { "ori": [21, 31911], "trs": [57, 31904], }, "sel": { "ori": [47, 5603], "trs": [66, 5491] } } },
		"郭鑫": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [251, 38119] }, "chn": { "ori": [72, 35968] }, "mat": { "ori": [28, 36384] }, "eng": { "ori": [33, 34095] }, "phy": { "ori": [18, 37577] }, "che": { "ori": [5, 33462], "trs": [42, 33462], }, "sel": { "ori": [31, 25124], "trs": [58, 25124] } } },
		"李一霖": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [219, 38325] }, "chn": { "ori": [60, 37972] }, "mat": { "ori": [24, 37228] }, "eng": { "ori": [24, 34520] }, "phy": { "ori": [16, 37867] }, "che": { "ori": [7, 33437], "trs": [44, 33437], }, "sel": { "ori": [18, 10838], "trs": [51, 10838] } } },
		"刘泽圳": { "sel": { "bio": false, "pol": true, "geo": false }, "main": { "tot": { "trs": [174, 38386] }, "chn": { "ori": [17, 38429] }, "mat": { "ori": [15, 38209] }, "eng": { "ori": [14, 34734] }, "phy": { "ori": [19, 37392] }, "che": { "ori": [23, 31335], "trs": [59, 31325], }, "sel": { "ori": [20, 6281], "trs": [50, 6281] } } },
		"童瑞祥": { "sel": { "bio": false, "pol": false, "geo": true }, "main": { "tot": { "trs": [111, 38453] }, "chn": { "ori": [null, 38443] }, "mat": { "ori": [null, 38454] }, "eng": { "ori": [null, 34749] }, "phy": { "ori": [0, 38393] }, "che": { "ori": [13, 33207], "trs": [49, 33207], }, "sel": { "ori": [35, 10118], "trs": [62, 10118] } } },
		"潘锦萱": { "sel": { "bio": true, "pol": false, "geo": false }, "main": { "tot": { "trs": [null, 38528] }, "chn": { "ori": [null, 38443] }, "mat": { "ori": [null, 38454] }, "eng": { "ori": [null, 34749] }, "phy": { "ori": [null, 38393] }, "che": { "ori": [null, 33469], "trs": [null, 33469], }, "sel": { "ori": [null, 26133], "trs": [null, 26133] } } },
	}
}

const tna = {
	"tot": 38528,
	"chn": 38443,
	"mat": 38454,
	"eng": 34749,
	"phy": 38393,
	"che": 33469,
	"bio": 26133,
	"pol": 6289,
	"geo": 10872,
}

const example = {
	"undefined": {
		"sel": {
			"bio": undefined,                         // 是否选生物 (Boolean)
			"pol": undefined,                         // 是否选政治 (Boolean)
			"geo": undefined                          // 是否选地理 (Boolean)
		},
		"main": {
			"tot": { "trs": [undefined, undefined] }, // 赋分总分 (分数, 市排)
			"chn": { "ori": [undefined, undefined] }, // 语文原分 (分数, 市排)
			"mat": { "ori": [undefined, undefined] }, // 数学原分 (分数, 市排)
			"eng": { "ori": [undefined, undefined] }, // 英语原分 (分数, 市排)
			"phy": { "ori": [undefined, undefined] }, // 物理原分 (分数, 市排)
			"che": {                                  // 化学成绩
				"ori": [undefined, undefined],        // 化学原分 (分数, 市排)
				"trs": [undefined, undefined],        // 化学赋分 (分数, 市排)
			},
			"sel": {                                  // 选科成绩
				"ori": [undefined, undefined],        // 选科原分 (分数, 市排)
				"trs": [undefined, undefined],        // 选科赋分 (分数, 市排)
			}
		}
	},
}